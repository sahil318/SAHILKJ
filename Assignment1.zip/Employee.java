package com.company;
import java.util.*;
public class Employee
{
    float basic;
    float hra;
    float da;

    public static void main(String[] args)
    {
        float GSA;
        int x;

        Scanner sc = new Scanner(System.in);
        Employee m = new Employee();
        System.out.print(" Basic salary =");
        m.basic = sc.nextFloat();
        System.out.println("SALARY CONDITION , BASIC SALARY < 10000 OR >=10000");
        x= sc.nextInt();
        System.out.print("\n");
        switch(x)
        {
            case 1:
             if (m.basic<10000)
             {
                 m.hra = ((10 * m.basic) / 100);
                 m.da = ((90 * m.basic) / 100);
                 GSA = m.basic + m.da + m.hra;
                 System.out.println("GSA OF AN EMPLOYEE IS " + GSA);
             }
             break;
            case 2:
                if (m.basic>=10000)
                {
                    {
                        m.hra = 2000;
                        m.da = ((98 * m.basic) / 100);
                        GSA = m.basic + m.da + m.hra;
                        System.out.println("GSA OF AN EMPLOYEE IS " + GSA);
                    }
                }
        }
    }
}