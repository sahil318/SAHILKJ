package assignment;
import java.util.*;



public class Marks
{

    public static void main(String[] args)
    {

		Scanner sc = new Scanner(System.in);
		int sub = sc.nextInt();
		int i;
		int total = 0;
		double per;
		System.out.println("ENTER 5 SUBJECT MARKS");
		for(i=1;i<=sub;i++)
		{
			int mark = sc.nextInt();
			total = total + mark;
			
		}
		per=((total*100)/500);
    	System.out.println("PERCENTAGE"+per);
    	


    }
}