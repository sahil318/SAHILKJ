import java.util.*;
class Fahrenheit
{
    public static void main(String[] args)
    {
        float f;
        float C;
        Scanner sc = new Scanner(System.in);
        System.out.print("ENTER TEMPERATURE IN Fahrenheit ");
        f = sc.nextFloat();
       C = (5*(f-32)/9);
        System.out.print("TEMPERATURE IN CELSIUS = " +C);

    }
}