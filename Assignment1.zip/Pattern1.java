class Pattern1
{
    public static void main(String[] args)
    {
        int i , j;
        for (i=0;i<=6;i++)
        {
            for (j=6;j>=0;j--)
                System.out.print(+i +" "+j+" ");
            System.out.println();
        }

    }

}

0 6 0 5 0 4 0 3 0 2 0 1 0 0 
1 6 1 5 1 4 1 3 1 2 1 1 1 0 
2 6 2 5 2 4 2 3 2 2 2 1 2 0 
3 6 3 5 3 4 3 3 3 2 3 1 3 0 
4 6 4 5 4 4 4 3 4 2 4 1 4 0 
5 6 5 5 5 4 5 3 5 2 5 1 5 0 
6 6 6 5 6 4 6 3 6 2 6 1 6 0 
